import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Welcome to My Web Page 🚀</h1>
      <p>This page is deployed on AWS EC2 using Terraform!</p>
    </div>
  );
}

export default App;
